import { readWorkspace, saveWorkspace, saveRecovery, readRecovery, migratePrototype, withWorkspaceLock } from './db.js';
import { uid, localDate, emptyData, sampleData, validateData, paidFor, balanceFor, cents, minutes, STATUSES, METHODS } from './domain.js';

const $ = selector => document.querySelector(selector);
const main = $('#main'), editor = $('#editor');
const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const money = value => new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(value / 100);
const dateLabel = date => new Date(date + 'T12:00:00').toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' });
const datetime = date => new Date(date).toLocaleString('es-MX', { dateStyle: 'medium', timeStyle: 'short' });
const initials = name => name.split(/\s+/).slice(0, 2).map(s => s[0] || '').join('');
let state, section = 'hoy', selectedDate = localDate(), selectedAppointment = '', recordPatient = '', query = '', statusFilter = '', showArchived = false, ledgerFilter = 'pending';
let syncBusy = false, conflict = false, syncError = '', toastTimer, installPrompt, uiSaving = false;
const channel = typeof BroadcastChannel === 'function' ? new BroadcastChannel('ronda-workspace') : null;
const withServerLock = task => navigator.locks ? navigator.locks.request('ronda-server-sync', task) : task();

const data = () => state.data;
const patient = id => data().patients.find(p => p.id === id);
const appointment = id => data().appointments.find(a => a.id === id);
const patientName = id => patient(id)?.name || 'Paciente';
const sorted = list => [...list].sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
const todayAppointments = () => sorted(data().appointments.filter(a => a.date === selectedDate));
const btn = (label, action, id = '', type = '') => '<button type="button" class="btn ' + type + '" data-action="' + action + '" data-id="' + esc(id) + '">' + label + '</button>';
const empty = (title, copy, actions = '') => '<div class="empty"><div class="empty-symbol" aria-hidden="true">○</div><strong>' + title + '</strong>' + copy + (actions ? '<div class="button-group">' + actions + '</div>' : '') + '</div>';
const badge = a => '<span class="badge ' + (a.status === 'cancelled' ? 'cancelled' : balanceFor(data(), a) ? 'pending' : 'paid') + '">' + (a.status === 'cancelled' ? 'Cancelada' : a.priceCents === 0 ? 'Sin cargo' : balanceFor(data(), a) === 0 ? 'Pagada' : paidFor(data(), a.id) ? 'Abono registrado' : 'Por cobrar') + '</span>';

function toast(message) {
  clearTimeout(toastTimer); $('#toast').textContent = message; $('#toast').classList.add('show');
  toastTimer = setTimeout(() => $('#toast').classList.remove('show'), 4500);
}
function syncStatus() {
  const copy = conflict ? 'Revisar cambios entre equipos' : !navigator.onLine ? (state?.dirty ? 'Sin conexión · cambios locales' : 'Sin conexión · datos locales') : syncBusy ? 'Guardando en el servidor…' : syncError ? 'Guardado local · servidor pendiente' : state?.dirty ? 'Cambios por respaldar' : state?.syncedAt ? 'Respaldado en este equipo' : 'Listo · respaldo al guardar';
  $('#sync-copy').textContent = copy;
  if ($('#settings-sync-copy')) $('#settings-sync-copy').textContent = copy;
  if ($('#settings-sync-time')) $('#settings-sync-time').textContent = state?.syncedAt ? 'Último respaldo: ' + datetime(state.syncedAt) : 'Todavía no hay un respaldo confirmado.';
  $('#sync-light').className = 'sync-light' + (conflict ? ' error' : state?.dirty || syncError || !navigator.onLine ? ' pending' : '');
}
async function request(path, options = {}) {
  const response = await fetch(path, { ...options, cache: 'no-store', signal: AbortSignal.timeout(6000) });
  const result = await response.json();
  if (!response.ok) { const error = new Error(result.error || 'No se pudo conectar con el servidor.'); error.status = response.status; throw error; }
  return result;
}
async function sync() {
  if (syncBusy || conflict || !state || !navigator.onLine) { syncStatus(); return; }
  syncBusy = true; syncError = ''; syncStatus();
  try {
    await withServerLock(async () => {
    const saved = await readWorkspace();
    if (saved) state = saved;
    if (!state.dirty) {
      const generation = state.generation;
      const remote = await request('/api/state');
      await withWorkspaceLock(async () => {
      const latest = await readWorkspace();
      if (latest && latest.generation !== state.generation) state = latest;
      if (remote.data && !state.dirty && generation === state.generation && remote.revision !== state.revision) {
        validateData(remote.data);
        state = { ...state, data: remote.data, generation: uid(), revision: remote.revision, syncedAt: remote.updatedAt };
        await saveWorkspace(state); channel?.postMessage('changed'); if (!editor.open) render();
      }
      });
    } else {
      const generation = state.generation;
      const result = await request('/api/state', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ revision: state.revision, data: state.data }) });
      await withWorkspaceLock(async () => {
        const latest = await readWorkspace();
        if (latest) state = latest;
        state = { ...state, revision: result.revision, syncedAt: result.updatedAt, dirty: state.generation !== generation };
        await saveWorkspace(state); channel?.postMessage('changed');
      });
    }
    });
  } catch (error) {
    if (error.status === 409) { conflict = true; if (section === 'ajustes') render(); toast('Hay cambios en otro navegador. Revisa el respaldo en Ajustes.'); }
    else syncError = error.message;
  } finally { syncBusy = false; syncStatus(); }
  if (state.dirty && !syncError && !conflict) queueMicrotask(sync);
}
async function commit(mutator, message) {
  if (uiSaving) throw new Error('Espera a que termine el guardado anterior.');
  uiSaving = true;
  const generation = state.generation;
  try {
    await withWorkspaceLock(async () => {
    const current = await readWorkspace();
    if (current && current.generation !== generation) { state = current; render(); throw new Error('Otra pestaña modificó los datos. Revisa la vista actual y vuelve a intentarlo.'); }
    const next = structuredClone(data()); mutator(next); validateData(next);
    const nextState = { ...state, data: next, generation: uid(), dirty: true, changedAt: new Date().toISOString() };
    await saveWorkspace(nextState); state = nextState;
    channel?.postMessage('changed'); syncStatus(); render(); if (message) toast(message);
    });
    void sync();
  } finally { uiSaving = false; }
}
function heading(title, copy, action = '', eyebrow = 'TU ESPACIO DE TRABAJO') {
  return '<div class="page-heading"><div><p class="overline">' + eyebrow + '</p><h1>' + title + '</h1><p>' + copy + '</p></div>' + action + '</div>';
}
function stats(items) {
  return '<div class="stats">' + items.map(([label, value, unit]) => '<div class="stat"><span>' + label + '</span><strong>' + value + '</strong><small>' + unit + '</small></div>').join('') + '</div>';
}
function week() {
  const current = new Date(selectedDate + 'T12:00:00');
  current.setDate(current.getDate() - (current.getDay() + 6) % 7);
  return '<div class="week-ruler" aria-label="Semana seleccionada">' + Array.from({ length: 7 }, (_, i) => {
    const d = new Date(current); d.setDate(d.getDate() + i); const key = localDate(d);
    const count = data().appointments.filter(a => a.date === key && a.status !== 'cancelled').length;
    return '<button data-action="date" data-id="' + key + '" class="' + (key === selectedDate ? 'selected' : '') + '" aria-pressed="' + (key === selectedDate) + '"><span>' + d.toLocaleDateString('es-MX', { weekday: 'short' }) + '</span><strong>' + String(d.getDate()).padStart(2, '0') + '</strong><small>' + (count ? count + ' citas' : 'Libre') + '</small></button>';
  }).join('') + '</div>';
}
function appointmentRows(list) {
  return list.map(a => '<article class="visit-row ' + a.status + (a.id === selectedAppointment ? ' active' : '') + '"><time class="visit-time">' + a.time + '</time><span class="visit-track"></span><button class="visit-main" data-action="select" data-id="' + a.id + '"><strong>' + esc(patientName(a.patientId)) + '</strong><small>' + esc(a.service) + ' · ' + a.duration + ' min · ' + STATUSES[a.status] + '</small></button><div class="visit-meta"><strong>' + money(a.priceCents) + '</strong>' + badge(a) + '</div></article>').join('');
}
function contextPanel() {
  const a = appointment(selectedAppointment);
  if (!a) return '<aside class="case-space"><div class="case-topline"><span>CONTEXTO DE LA CONSULTA</span><span>RONDA</span></div>' + empty('Todo en su lugar', 'Selecciona una cita para consultar el expediente, registrar su llegada y llevar el cobro.') + '</aside>';
  const p = patient(a.patientId);
  const note = data().notes.filter(n => n.patientId === p.id).sort((x, y) => y.createdAt.localeCompare(x.createdAt))[0];
  return '<aside class="case-space"><div class="case-topline"><span>CONTEXTO ACTIVO</span><span>' + a.time + ' · ' + a.duration + ' MIN</span></div><div class="case-identity"><div class="avatar">' + esc(initials(p.name)) + '</div><div><h2>' + esc(p.name) + '</h2><small>' + STATUSES[a.status] + ' · ' + esc(a.service) + '</small></div></div><section><h3>Continuidad del expediente</h3>' + (note ? '<blockquote>' + esc(note.content.slice(0, 260)) + '</blockquote><small class="muted">' + datetime(note.createdAt) + '</small>' : '<p>La historia de cada paciente empieza con una nota. Registra los hallazgos y el plan de su consulta.</p>') + '</section><section><h3>Antecedentes y alertas</h3><p>' + esc(p.allergies ? 'Alergias: ' + p.allergies : 'Sin alergias registradas') + '</p><p>' + esc(p.background.slice(0, 200) || 'Sin antecedentes registrados') + '</p></section><div class="charge-line"><span><small>Saldo de esta consulta</small><strong>' + money(balanceFor(data(), a)) + '</strong></span>' + badge(a) + '</div><div class="button-group">' +
    (a.status === 'scheduled' ? btn('Marcar llegada', 'arrive', a.id) : '') +
    (a.status === 'arrived' || a.status === 'scheduled' ? btn('Atendida ✓', 'complete', a.id) : '') +
    btn('Abrir expediente ↗', 'record', p.id, 'wide') + btn('＋ Nota de sesión', 'new-note', a.id, 'wide primary') +
    (balanceFor(data(), a) ? btn('Registrar pago', 'payment', a.id, 'wide') : '') + btn('Editar cita', 'edit-appointment', a.id, 'wide link') + '</div></aside>';
}
function renderToday() {
  const list = todayAppointments();
  const active = list.filter(a => a.status !== 'cancelled');
  if (!list.some(a => a.id === selectedAppointment)) {
    selectedAppointment = (active.find(a => a.status === 'arrived') || active.find(a => a.status === 'scheduled' && new Date(a.date + 'T' + a.time).getTime() >= Date.now()) || active.find(a => a.status === 'scheduled') || active[0])?.id || '';
  }
  const a = appointment(selectedAppointment);
  const title = a ? esc(patientName(a.patientId).split(' ')[0]) + ', tu consulta en contexto.' : 'Tu día, con espacio para todo.';
  const total = active.reduce((sum, a) => sum + balanceFor(data(), a), 0);
  return '<div class="workbench"><section class="day-space">' + heading(title, a ? a.time + ' · ' + esc(a.service) + ' · ' + a.duration + ' minutos' : 'Organiza tus consultas y da continuidad a cada paciente.', btn('＋ Nueva cita', 'new-appointment', '', 'primary'), esc(dateLabel(selectedDate))) +
    (!data().patients.length ? '<section class="onboarding"><h2>Bienvenido a tu consulta.</h2><p>Agrega tu primer paciente y programa una cita. Cada cambio se guarda en el navegador y se respalda en el servidor local cuando está disponible.</p><div class="button-group">' + btn('Agregar paciente', 'new-patient', '', 'primary') + btn('Explorar con ejemplos', 'load-sample') + '</div></section>' : '') +
    stats([['Consultas del día', String(active.length).padStart(2, '0'), 'programadas'], ['Ya atendidas', active.filter(a => a.status === 'completed').length, 'consultas'], ['Saldo del día', money(total), 'por cobrar']]) +
    '<div class="toolbar"><span class="overline">' + esc(dateLabel(selectedDate)) + '</span><div class="button-group">' + btn('←', 'previous-day') + btn('Hoy', 'today') + btn('→', 'next-day') + '</div></div>' + week() +
    '<section class="panel"><div class="section-heading"><div><span class="section-code">01</span><h2>Flujo del día</h2></div><span class="badge">' + active.length + ' consultas</span></div>' + (list.length ? appointmentRows(list) : empty('No tienes citas este día', 'Puedes reservar un horario y elegir un paciente.', btn('Agendar una consulta', 'new-appointment'))) + '</section></section>' + contextPanel() + '</div>';
}
function renderAgenda() {
  const list = todayAppointments().filter(a => !statusFilter || a.status === statusFilter);
  return '<div class="page">' + heading('Agenda de consultas', 'Cada cita conectada con su paciente, expediente y cobro.', btn('＋ Nueva cita', 'new-appointment', '', 'primary'), 'OPERACIÓN DIARIA') +
    '<div class="toolbar"><div class="filters"><label>Fecha<input id="agenda-date" type="date" value="' + selectedDate + '"></label><label>Estado<select id="agenda-status"><option value="">Todos los estados</option>' + Object.entries(STATUSES).map(([value, label]) => '<option value="' + value + '"' + (value === statusFilter ? ' selected' : '') + '>' + label + '</option>').join('') + '</select></label></div><div class="button-group">' + btn('← Día anterior', 'previous-day') + btn('Hoy', 'today') + btn('Día siguiente →', 'next-day') + '</div></div>' + week() +
    '<section class="panel"><div class="section-heading"><h2>' + esc(dateLabel(selectedDate)) + '</h2><span class="badge">' + list.length + ' citas</span></div>' +
    (list.length ? '<div class="table-wrap"><table><thead><tr><th>Horario</th><th>Paciente y servicio</th><th>Consulta</th><th>Saldo</th><th>Acciones</th></tr></thead><tbody>' + list.map(a => '<tr><td><strong>' + a.time + '</strong><small>' + a.duration + ' minutos</small></td><td><button class="visit-main" data-action="record" data-id="' + a.patientId + '"><strong>' + esc(patientName(a.patientId)) + '</strong><small>' + esc(a.service) + '</small></button></td><td><span class="badge">' + STATUSES[a.status] + '</span></td><td><strong>' + money(balanceFor(data(), a)) + '</strong>' + badge(a) + '</td><td><div class="button-group">' + btn('Editar', 'edit-appointment', a.id, 'small') + (a.status !== 'cancelled' ? btn('Nota', 'new-note', a.id, 'small') : '') + (balanceFor(data(), a) ? btn('Cobrar', 'payment', a.id, 'small') : '') + '</div></td></tr>').join('') + '</tbody></table></div>' : empty('Un día disponible', 'No hay consultas con esta fecha y estado.')) + '</section></div>';
}
function renderPatients() {
  const search = query.trim().toLocaleLowerCase();
  const list = data().patients.filter(p => p.archived === showArchived && (p.name + ' ' + p.phone + ' ' + p.email).toLocaleLowerCase().includes(search)).sort((a, b) => a.name.localeCompare(b.name, 'es'));
  return '<div class="page">' + heading('Personas, no números.', 'Datos de contacto, antecedentes y evolución en un mismo lugar.', btn('＋ Nuevo paciente', 'new-patient', '', 'primary'), 'PACIENTES Y EXPEDIENTES') +
    '<div class="toolbar"><input type="search" id="patient-search" aria-label="Buscar paciente" placeholder="Buscar por nombre, teléfono o correo…" value="' + esc(query) + '"><label><span><input id="archived-filter" type="checkbox"' + (showArchived ? ' checked' : '') + '> Mostrar archivados</span></label><span class="muted">' + list.length + ' pacientes</span></div><div class="patient-list">' +
    (list.length ? list.map(p => '<article class="patient-card"><div class="patient-top"><div class="avatar">' + esc(initials(p.name)) + '</div><div><strong>' + esc(p.name) + '</strong><small>' + esc(p.phone || p.email || 'Sin datos de contacto') + '</small></div></div><p>' + data().appointments.filter(a => a.patientId === p.id && a.status === 'completed').length + ' consultas atendidas · ' + data().notes.filter(n => n.patientId === p.id).length + ' notas</p><div class="button-group">' + btn('Abrir expediente ↗', 'record', p.id, 'primary') + btn('Editar', 'edit-patient', p.id) + '</div></article>').join('') : empty('Sin pacientes en esta lista', 'Agrega un paciente o prueba otra búsqueda.')) + '</div></div>';
}
function renderRecord() {
  const p = patient(recordPatient); if (!p) { recordPatient = ''; return renderPatients(); }
  const notes = data().notes.filter(n => n.patientId === p.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const visits = sorted(data().appointments.filter(a => a.patientId === p.id)).reverse();
  return '<div class="page">' + heading(esc(p.name), 'Expediente y seguimiento de consultas.', btn('← Todos los pacientes', 'patients'), 'EXPEDIENTE DEL PACIENTE') +
    '<div class="record-layout"><aside class="panel record-sidebar"><div class="avatar">' + esc(initials(p.name)) + '</div><h2>Ficha del paciente</h2>' + (p.archived ? '<span class="badge cancelled">Archivado</span>' : '') + '<dl><dt>Teléfono</dt><dd>' + esc(p.phone || 'Sin registrar') + '</dd><dt>Correo</dt><dd>' + esc(p.email || 'Sin registrar') + '</dd><dt>Fecha de nacimiento</dt><dd>' + esc(p.birthDate || 'Sin registrar') + '</dd><dt>Alergias</dt><dd>' + esc(p.allergies || 'Sin registrar') + '</dd><dt>Antecedentes</dt><dd>' + esc(p.background || 'Sin registrar') + '</dd></dl><div class="button-group">' + btn('Editar ficha', 'edit-patient', p.id) + btn(p.archived ? 'Reactivar' : 'Archivar', 'archive-patient', p.id, 'link') + '</div></aside><div class="record-content"><section class="panel"><div class="section-heading"><h2>Notas de evolución</h2>' + btn('＋ Agregar nota', 'patient-note', p.id, 'small primary') + '</div>' + (notes.length ? notes.map(n => '<article class="note"><time>' + datetime(n.createdAt) + '</time><p>' + esc(n.content) + '</p>' + (n.plan ? '<small>PLAN DE SEGUIMIENTO</small><p>' + esc(n.plan) + '</p>' : '') + (n.appointmentId ? '<small>Consulta: ' + esc(appointment(n.appointmentId)?.service) + '</small>' : '') + '</article>').join('') : empty('La evolución comienza aquí', 'Agrega una nota después de cada consulta.')) + '</section><section class="panel"><div class="section-heading"><h2>Historial de consultas</h2>' + (!p.archived ? btn('Agendar', 'patient-appointment', p.id, 'small') : '') + '</div>' + (visits.length ? visits.map(a => '<article class="note"><div class="toolbar"><span><strong>' + esc(a.service) + '</strong><small class="muted"> · ' + a.date + ' · ' + a.time + '</small></span>' + badge(a) + '</div><div class="button-group">' + btn('Ver cita', 'edit-appointment', a.id, 'small') + (balanceFor(data(), a) ? btn('Registrar pago · ' + money(balanceFor(data(), a)), 'payment', a.id, 'small') : '') + '</div></article>').join('') : empty('Aún no hay consultas', 'Su historial aparecerá al programar una cita.')) + '</section></div></div></div>';
}
function renderPayments() {
  const pending = sorted(data().appointments.filter(a => balanceFor(data(), a) > 0));
  const ledger = [...data().payments].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const received = ledger.filter(p => !p.voidedAt).reduce((sum, p) => sum + p.amountCents, 0);
  const month = ledger.filter(p => !p.voidedAt && localDate(new Date(p.createdAt)).slice(0, 7) === localDate().slice(0, 7)).reduce((sum, p) => sum + p.amountCents, 0);
  return '<div class="page">' + heading('Cuentas claras.', 'Registra pagos y anticipos recibidos. Cada abono actualiza el saldo de la consulta.', btn('Exportar movimientos ↓', 'export-payments'), 'COBROS Y COMPROBANTES') +
    stats([['Por cobrar', money(pending.reduce((sum, a) => sum + balanceFor(data(), a), 0)), pending.length + ' consultas'], ['Recibido este mes', money(month), 'pagos registrados'], ['Total recibido', money(received), 'histórico']]) +
    '<div class="toolbar"><div class="button-group">' + btn('Saldos pendientes (' + pending.length + ')', 'ledger-pending', '', ledgerFilter === 'pending' ? 'primary' : '') + btn('Movimientos (' + ledger.length + ')', 'ledger-history', '', ledgerFilter === 'history' ? 'primary' : '') + '</div><small class="muted">Registro manual · no procesa tarjetas</small></div><section class="panel">' +
    (ledgerFilter === 'pending' ? (pending.length ? '<div class="table-wrap"><table><thead><tr><th>Paciente</th><th>Consulta</th><th>Costo</th><th>Recibido</th><th>Saldo</th><th></th></tr></thead><tbody>' + pending.map(a => '<tr><td><strong>' + esc(patientName(a.patientId)) + '</strong></td><td>' + esc(a.service) + '<small>' + a.date + ' · ' + a.time + '</small></td><td>' + money(a.priceCents) + '</td><td>' + money(paidFor(data(), a.id)) + '</td><td><strong>' + money(balanceFor(data(), a)) + '</strong></td><td>' + btn('Registrar pago', 'payment', a.id, 'small primary') + '</td></tr>').join('') + '</tbody></table></div>' : empty('Tus cuentas están al día', 'No hay saldos pendientes de las consultas activas.')) :
      (ledger.length ? '<div class="table-wrap"><table><thead><tr><th>Fecha y folio</th><th>Paciente</th><th>Importe</th><th>Método</th><th>Acciones</th></tr></thead><tbody>' + ledger.map(p => '<tr><td>' + datetime(p.createdAt) + '<small>' + esc(p.id.slice(0, 8).toUpperCase()) + '</small></td><td>' + esc(patientName(appointment(p.appointmentId).patientId)) + (p.voidedAt ? '<small>Anulado: ' + esc(p.voidReason) + '</small>' : '') + '</td><td><strong>' + money(p.amountCents) + '</strong>' + (p.voidedAt ? '<span class="badge cancelled">Anulado</span>' : '') + '</td><td>' + esc(p.method) + '</td><td><div class="button-group">' + btn('Comprobante', 'receipt', p.id, 'small') + (!p.voidedAt ? btn('Anular', 'void-payment', p.id, 'small link') : '') + '</div></td></tr>').join('') + '</tbody></table></div>' : empty('Sin movimientos todavía', 'Los pagos y anticipos recibidos aparecerán aquí.'))) + '</section></div>';
}
function renderSettings() {
  const s = data().settings;
  return '<div class="page">' + heading('A tu manera.', 'Configura la consulta, los recordatorios y tus respaldos.', '', 'AJUSTES DE TU ESPACIO') +
    (conflict ? '<div class="notice"><strong>Hay cambios guardados desde otro navegador.</strong> Tu versión local sigue protegida. Descárgala antes de cargar la versión del servidor.<div class="button-group">' + btn('Descargar mis datos locales', 'export-backup') + btn('Cargar versión del servidor', 'resolve-conflict') + '</div></div>' : '') +
    '<div class="settings-grid"><section class="panel settings-card"><h2>Perfil de la consulta</h2><form id="settings-form"><label>Nombre del espacio<input name="practice" value="' + esc(s.practice) + '" required maxlength="100"></label><label>Profesional<input name="professional" value="' + esc(s.professional) + '" maxlength="120"></label><div class="form-row"><label>Inicio de jornada<input name="start" type="time" value="' + s.start + '" required></label><label>Fin de jornada<input name="end" type="time" value="' + s.end + '" required></label></div><label>Avisar antes de la cita<select name="reminderMinutes">' + [5, 10, 15, 30, 60].map(n => '<option value="' + n + '"' + (n === s.reminderMinutes ? ' selected' : '') + '>' + n + ' minutos</option>').join('') + '</select></label><div class="form-error" role="alert" hidden></div><button class="btn primary" type="submit">Guardar configuración</button></form></section>' +
    '<section class="panel settings-card"><h2>Datos y respaldo</h2><p>Las citas, fichas, notas y pagos se guardan en IndexedDB. Cuando el servidor está disponible, también se respaldan en SQLite en esta computadora.</p><div class="info-line"><strong>Estado actual</strong><br><span id="settings-sync-copy">' + esc($('#sync-copy').textContent) + '</span><br><small id="settings-sync-time">' + (state.syncedAt ? 'Último respaldo: ' + datetime(state.syncedAt) : 'Todavía no hay un respaldo confirmado.') + '</small></div><div class="button-group">' + btn('Respaldar ahora', 'sync') + btn('Descargar respaldo JSON', 'export-backup') + '</div><label>Restaurar respaldo<input id="import-backup" type="file" accept=".json,application/json"></label><p>Antes de restaurar se conserva una copia de recuperación de tu información actual.</p><div class="button-group">' + btn('Recuperar copia anterior', 'recover') + '</div></section>' +
    '<section class="panel settings-card"><h2>Recordatorios de citas</h2><p>Recibe avisos locales mientras Ronda está abierta. El navegador solicita permiso solo cuando activas esta opción.</p><div class="button-group">' + btn('Activar notificaciones', 'enable-notifications') + '</div><p>Permiso: ' + ('Notification' in window ? esc(Notification.permission) : 'No disponible en este navegador') + '. Los avisos con la aplicación cerrada y los mensajes al paciente requieren un servicio Push externo.</p></section><section class="panel settings-card"><h2>Acerca de esta versión</h2><p>Ronda 1.0 · operación local para un profesional. Agenda, pacientes, notas de seguimiento, pagos manuales y exportación de comprobantes.</p><div class="info-line">El servidor acepta conexiones únicamente desde esta computadora. El respaldo no es una cuenta en la nube.</div><div class="info-line">Pagos con Stripe o Mercado Pago, autenticación remota y suscripciones SaaS: pendientes de integración.</div><p>Para empezar con ejemplos ficticios, utiliza la bienvenida cuando el espacio esté vacío.</p></section></div></div>';
}
function render() {
  if (!state) return;
  $('#practice-label').textContent = data().settings.practice;
  document.title = 'Ronda · ' + ({ hoy: 'Hoy', agenda: 'Agenda', personas: recordPatient ? 'Expediente' : 'Pacientes', cobros: 'Cobros', ajustes: 'Ajustes' }[section]);
  document.querySelectorAll('[data-section]').forEach(el => { el.classList.toggle('is-active', el.dataset.section === section); el.setAttribute('aria-current', el.dataset.section === section ? 'page' : 'false'); });
  main.innerHTML = section === 'hoy' ? renderToday() : section === 'agenda' ? renderAgenda() : section === 'personas' ? (recordPatient ? renderRecord() : renderPatients()) : section === 'cobros' ? renderPayments() : renderSettings();
  main.querySelectorAll('form').forEach(form => { form.dataset.generation = state.generation; });
  syncStatus();
}
function navigate(target) {
  section = ['hoy', 'agenda', 'personas', 'cobros', 'ajustes'].includes(target) ? target : 'hoy';
  if (section !== 'personas') recordPatient = '';
  query = ''; history.replaceState(null, '', '#' + section); render(); window.scrollTo({ top: 0 });
}
function dialog(title, content, eyebrow = 'RONDA · TU CONSULTA') {
  editor.dataset.generation = state.generation;
  $('#dialog-content').innerHTML = '<div class="dialog-heading"><div><p>' + eyebrow + '</p><h2 id="dialog-title">' + title + '</h2></div><button class="dialog-close" data-action="close" aria-label="Cerrar">×</button></div><div class="dialog-body">' + content + '</div>';
  if (!editor.open) editor.showModal();
}
const formEnd = label => '<div class="form-error" role="alert" hidden></div><div class="form-actions">' + btn('Cancelar', 'close') + '<button class="btn primary" type="submit">' + label + '</button></div></form>';
function patientDialog(id = '', after = '') {
  const p = patient(id) || { name: '', phone: '', email: '', birthDate: '', background: '', allergies: '' };
  dialog(id ? 'Editar paciente' : 'Nuevo paciente', '<form id="patient-form" data-id="' + id + '" data-after="' + after + '"><label>Nombre completo<input name="name" required maxlength="120" value="' + esc(p.name) + '" autocomplete="name"></label><div class="form-row"><label>Teléfono<input name="phone" type="tel" maxlength="40" value="' + esc(p.phone) + '"></label><label>Nacimiento<input name="birthDate" type="date" max="' + localDate() + '" value="' + p.birthDate + '"></label></div><label>Correo<input name="email" type="email" maxlength="150" value="' + esc(p.email) + '"></label><label>Alergias o alertas<textarea name="allergies" maxlength="2000" rows="2">' + esc(p.allergies) + '</textarea></label><label>Antecedentes<textarea name="background" maxlength="10000" rows="3">' + esc(p.background) + '</textarea></label>' + formEnd('Guardar paciente'));
}
function appointmentDialog(id = '', patientId = '') {
  if (!data().patients.some(p => !p.archived) && !id) { patientDialog('', 'appointment'); return; }
  const a = appointment(id) || { patientId, date: selectedDate, time: '13:30', duration: 45, service: '', priceCents: 0, status: 'scheduled' };
  const patients = data().patients.filter(p => !p.archived || p.id === a.patientId).sort((a, b) => a.name.localeCompare(b.name));
  dialog(id ? 'Editar consulta' : 'Nueva consulta', '<form id="appointment-form" data-id="' + id + '"><label>Paciente<select name="patientId" required><option value="">Seleccionar paciente</option>' + patients.map(p => '<option value="' + p.id + '"' + (p.id === a.patientId ? ' selected' : '') + '>' + esc(p.name) + '</option>').join('') + '</select></label>' + (!id ? btn('＋ Agregar un paciente nuevo', 'patient-for-appointment', '', 'link small') : '') + '<div class="form-row"><label>Fecha<input name="date" type="date" value="' + a.date + '" required></label><label>Hora<input name="time" type="time" value="' + a.time + '" required></label></div><div class="form-row"><label>Duración en minutos<input name="duration" type="number" min="5" max="480" step="5" value="' + a.duration + '" required></label><label>Precio MXN<input name="price" type="number" min="0" max="1000000" step=".01" value="' + a.priceCents / 100 + '" required></label></div><label>Servicio o motivo<input name="service" maxlength="160" value="' + esc(a.service) + '" placeholder="Ej. Consulta de seguimiento" required></label>' + (id ? '<label>Estado<select name="status">' + Object.entries(STATUSES).map(([value, label]) => '<option value="' + value + '"' + (value === a.status ? ' selected' : '') + '>' + label + '</option>').join('') + '</select></label>' : '') + '<p class="dialog-summary">El horario no puede cruzarse con otra consulta. Jornada: ' + data().settings.start + ' a ' + data().settings.end + '.</p>' + formEnd('Guardar cita'));
}
function noteDialog(patientId, appointmentId = '') {
  const p = patient(patientId);
  dialog('Nota de seguimiento', '<p class="dialog-summary">' + esc(p.name) + (appointmentId ? ' · ' + esc(appointment(appointmentId).service) : '') + '</p><form id="note-form" data-patient="' + patientId + '" data-appointment="' + appointmentId + '"><label>Evolución o hallazgos<textarea name="content" rows="5" maxlength="10000" placeholder="Registra lo observado en esta consulta…" required></textarea></label><label>Plan para la próxima consulta<textarea name="plan" rows="3" maxlength="5000"></textarea></label>' + formEnd('Guardar nota'));
}
function paymentDialog(id) {
  const a = appointment(id); const balance = balanceFor(data(), a);
  if (balance <= 0) return toast('Esta consulta no tiene saldo pendiente.');
  dialog('Registrar pago', '<p class="dialog-summary">' + esc(patientName(a.patientId)) + ' · ' + esc(a.service) + '<br>' + a.date + ' · ' + a.time + '</p><div class="payment-summary"><span>Saldo pendiente</span><strong>' + money(balance) + '</strong></div><form id="payment-form" data-id="' + id + '"><label>Importe recibido MXN<input name="amount" type="number" step=".01" min=".01" max="' + balance / 100 + '" value="' + balance / 100 + '" required></label><label>Método<select name="method">' + METHODS.map(m => '<option>' + m + '</option>').join('') + '</select></label><label>Referencia opcional<input name="reference" maxlength="200" placeholder="Ej. Folio de transferencia"></label><p class="dialog-summary">Registra únicamente un pago que ya recibiste. Puedes ingresar un anticipo menor al saldo.</p>' + formEnd('Confirmar pago recibido'));
}
function receiptText(p) {
  const a = appointment(p.appointmentId);
  return data().settings.practice + '\nCOMPROBANTE DE PAGO' + (p.voidedAt ? ' · ANULADO' : '') + '\nFolio: ' + p.id.slice(0, 8).toUpperCase() + '\nFecha: ' + datetime(p.createdAt) + '\nPaciente: ' + patientName(a.patientId) + '\nServicio: ' + a.service + '\nConsulta: ' + a.date + ' ' + a.time + '\nRecibido: ' + money(p.amountCents) + '\nMétodo: ' + p.method + (p.reference ? '\nReferencia: ' + p.reference : '') + '\nSaldo actual: ' + money(balanceFor(data(), a)) + (p.voidedAt ? '\nMotivo de anulación: ' + p.voidReason : '') + '\n\nComprobante de registro. No es una factura fiscal.';
}
function receiptDialog(id) {
  const p = data().payments.find(p => p.id === id);
  dialog('Comprobante de pago', '<div class="receipt">' + esc(receiptText(p)) + '</div><div class="button-group">' + btn('Compartir o copiar', 'share-receipt', id, 'primary') + btn('Descargar TXT', 'download-receipt', id) + '</div>');
}
function download(name, content, type = 'application/json') {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 2000);
}
function exportBackup() {
  download('ronda-respaldo-' + localDate() + '.json', JSON.stringify({ format: 'ronda-backup', exportedAt: new Date().toISOString(), data: data() }, null, 2));
}
async function restore(next) {
  validateData(next);
  await saveRecovery(state);
  await commit(d => { for (const key of Object.keys(d)) delete d[key]; Object.assign(d, next); }, 'Respaldo restaurado. Conservamos una copia de recuperación.');
}
function shiftDay(delta) { const date = new Date(selectedDate + 'T12:00:00'); date.setDate(date.getDate() + delta); selectedDate = localDate(date); selectedAppointment = ''; render(); }

document.addEventListener('click', async event => {
  const nav = event.target.closest('[data-section]');
  if (nav) { if (editor.open) editor.close(); recordPatient = ''; navigate(nav.dataset.section); return; }
  const target = event.target.closest('[data-action]');
  if (!target || !state) return;
  const { action, id } = target.dataset;
  try {
    if (action === 'close') { editor.close(); return; }
    if (action === 'new-patient' || action === 'patient-for-appointment') return patientDialog('', action === 'patient-for-appointment' ? 'appointment' : '');
    if (action === 'edit-patient') return patientDialog(id);
    if (action === 'new-appointment') return appointmentDialog();
    if (action === 'patient-appointment') return appointmentDialog('', id);
    if (action === 'edit-appointment') return appointmentDialog(id);
    if (action === 'select') { selectedAppointment = id; render(); return; }
    if (action === 'date') { selectedDate = id; selectedAppointment = ''; render(); return; }
    if (action === 'previous-day' || action === 'next-day') return shiftDay(action === 'previous-day' ? -1 : 1);
    if (action === 'today') { selectedDate = localDate(); selectedAppointment = ''; render(); return; }
    if (action === 'record') { recordPatient = id; navigate('personas'); return; }
    if (action === 'patients') { recordPatient = ''; navigate('personas'); return; }
    if (action === 'new-note') return noteDialog(appointment(id).patientId, id);
    if (action === 'patient-note') return noteDialog(id);
    if (action === 'payment') return paymentDialog(id);
    if (action === 'receipt') return receiptDialog(id);
    if (action === 'arrive' || action === 'complete') return await commit(d => { d.appointments.find(a => a.id === id).status = action === 'arrive' ? 'arrived' : 'completed'; }, action === 'arrive' ? 'Llegada registrada.' : 'Consulta marcada como atendida.');
    if (action === 'archive-patient') {
      const p = patient(id);
      if (!p.archived && data().appointments.some(a => a.patientId === id && ['scheduled', 'arrived'].includes(a.status))) throw new Error('Atiende o cancela las citas pendientes antes de archivar al paciente.');
      if (!p.archived && !confirm('¿Archivar a ' + p.name + '? Su expediente e historial se conservan.')) return;
      return await commit(d => { const entry = d.patients.find(p => p.id === id); entry.archived = !entry.archived; }, p.archived ? 'Paciente reactivado.' : 'Paciente archivado.');
    }
    if (action === 'ledger-pending' || action === 'ledger-history') { ledgerFilter = action === 'ledger-pending' ? 'pending' : 'history'; render(); return; }
    if (action === 'void-payment') {
      dialog('Anular registro de pago', '<p class="dialog-summary">La anulación conserva el movimiento y vuelve a abrir el saldo. No realiza devoluciones de dinero.</p><form id="void-form" data-id="' + id + '"><label>Motivo de anulación<textarea name="reason" required maxlength="300"></textarea></label>' + formEnd('Anular registro')); return;
    }
    if (action === 'share-receipt' || action === 'download-receipt') {
      const text = receiptText(data().payments.find(p => p.id === id));
      if (action === 'download-receipt') download('ronda-comprobante-' + id.slice(0, 8) + '.txt', text, 'text/plain;charset=utf-8');
      else if (navigator.share) { try { await navigator.share({ title: 'Comprobante Ronda', text }); } catch (error) { if (error.name !== 'AbortError') throw error; } }
      else { try { await navigator.clipboard.writeText(text); toast('Comprobante copiado. Puedes pegarlo en WhatsApp.'); } catch { download('comprobante-ronda.txt', text, 'text/plain'); toast('Descargamos el comprobante para compartirlo.'); } }
      return;
    }
    if (action === 'load-sample') {
      if (data().patients.length || data().appointments.length) throw new Error('Los ejemplos solo se cargan en un espacio vacío.');
      await commit(d => Object.assign(d, sampleData()), 'Datos ficticios cargados.'); return;
    }
    if (action === 'export-backup') return exportBackup();
    if (action === 'sync') { await sync(); toast(conflict ? 'Revisa los cambios pendientes en Ajustes.' : syncError ? 'Datos locales guardados. El servidor todavía no está disponible.' : state.dirty ? 'Hay cambios pendientes de respaldo.' : 'Respaldo confirmado en el servidor local.'); return; }
    if (action === 'enable-notifications') {
      if (!('Notification' in window)) throw new Error('Este navegador no admite notificaciones.');
      const permission = await Notification.requestPermission(); render(); toast(permission === 'granted' ? 'Recordatorios activados mientras la app esté abierta.' : 'Los avisos siguen desactivados.'); return;
    }
    if (action === 'resolve-conflict') {
      const remote = await request('/api/state'); if (!remote.data) throw new Error('No hay información en el servidor.');
      validateData(remote.data);
      if (!confirm('¿Cargar la versión del servidor? Tu versión local se conservará como copia de recuperación.')) return;
      await saveRecovery(state); state = { ...state, data: remote.data, revision: remote.revision, syncedAt: remote.updatedAt, dirty: false, generation: uid() };
      await saveWorkspace(state); conflict = false; syncError = ''; channel?.postMessage('changed'); render(); toast('Versión del servidor cargada.'); return;
    }
    if (action === 'recover') {
      const recovery = await readRecovery(); if (!recovery) throw new Error('No hay una copia anterior para recuperar.');
      if (confirm('¿Restaurar la copia de recuperación anterior?')) await restore(recovery.data); return;
    }
    if (action === 'export-payments') {
      const csvCell = value => '"' + String(value).replaceAll('"', '""').replace(/^[=+@-]/, "'$&") + '"';
      const rows = [['Folio', 'Fecha', 'Paciente', 'Servicio', 'Importe MXN', 'Método', 'Estado', 'Referencia']];
      data().payments.forEach(p => { const a = appointment(p.appointmentId); rows.push([p.id, p.createdAt, patientName(a.patientId), a.service, (p.amountCents / 100).toFixed(2), p.method, p.voidedAt ? 'Anulado' : 'Recibido', p.reference]); });
      download('ronda-movimientos-' + localDate() + '.csv', '\ufeff' + rows.map(row => row.map(csvCell).join(',')).join('\r\n'), 'text/csv;charset=utf-8'); return;
    }
  } catch (error) { toast(error.message); }
});
document.addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.target; if (!form.reportValidity()) return;
  const submit = form.querySelector('[type=submit]'); if (submit.disabled) return;
  submit.disabled = true;
  const values = Object.fromEntries(new FormData(form));
  Object.keys(values).forEach(k => { if (typeof values[k] === 'string') values[k] = values[k].trim(); });
  const errorBox = form.querySelector('.form-error'); if (errorBox) errorBox.hidden = true;
  try {
    const expected = editor.contains(form) ? editor.dataset.generation : form.dataset.generation;
    if (expected !== state.generation) throw new Error('Los datos cambiaron en otra pestaña. Cierra y vuelve a abrir el formulario para trabajar con la versión actual.');
    if (form.id === 'patient-form') {
      const id = form.dataset.id || uid(); const after = form.dataset.after;
      await commit(d => {
        const entry = { id, name: values.name, phone: values.phone, email: values.email, birthDate: values.birthDate, background: values.background, allergies: values.allergies, archived: d.patients.find(p => p.id === id)?.archived || false };
        const index = d.patients.findIndex(p => p.id === id); if (index >= 0) d.patients[index] = entry; else d.patients.push(entry);
      }, 'Ficha del paciente guardada.');
      if (after === 'appointment') appointmentDialog('', id); else editor.close();
    } else if (form.id === 'appointment-form') {
      const id = form.dataset.id || uid();
      if (values.time < data().settings.start || minutes(values.time) + Number(values.duration) > minutes(data().settings.end)) throw new Error('La consulta debe quedar dentro del horario de tu jornada.');
      const nextStatus = values.status || 'scheduled';
      if (patient(values.patientId)?.archived && ['scheduled', 'arrived'].includes(nextStatus)) throw new Error('Reactiva al paciente antes de programar una nueva consulta.');
      if (nextStatus === 'cancelled' && appointment(id)?.status !== 'cancelled' && !confirm('¿Cancelar esta consulta? Los pagos recibidos se conservan y cualquier devolución debe hacerse por separado.')) return;
      await commit(d => {
        const a = { id, patientId: values.patientId, date: values.date, time: values.time, duration: Number(values.duration), service: values.service, priceCents: cents(values.price), status: nextStatus };
        const index = d.appointments.findIndex(a => a.id === id); if (index >= 0) d.appointments[index] = a; else d.appointments.push(a);
      }, 'Consulta guardada.'); selectedDate = values.date; selectedAppointment = id; editor.close(); render();
    } else if (form.id === 'note-form') {
      await commit(d => d.notes.push({ id: uid(), patientId: form.dataset.patient, appointmentId: form.dataset.appointment, content: values.content, plan: values.plan, createdAt: new Date().toISOString() }), 'Nota de seguimiento guardada.'); editor.close();
    } else if (form.id === 'payment-form') {
      const id = form.dataset.id, amountCents = cents(values.amount);
      if (!Number.isSafeInteger(amountCents) || amountCents <= 0 || amountCents > balanceFor(data(), appointment(id))) throw new Error('El importe debe ser mayor que cero y no superar el saldo pendiente.');
      const paymentId = uid();
      await commit(d => d.payments.push({ id: paymentId, appointmentId: id, amountCents, method: values.method, reference: values.reference, createdAt: new Date().toISOString() }), 'Pago registrado.'); receiptDialog(paymentId);
    } else if (form.id === 'void-form') {
      await commit(d => { const p = d.payments.find(p => p.id === form.dataset.id); if (p.voidedAt) throw new Error('Este pago ya está anulado.'); p.voidedAt = new Date().toISOString(); p.voidReason = values.reason; }, 'Registro anulado. El saldo fue actualizado.'); editor.close();
    } else if (form.id === 'settings-form') {
      await commit(d => { d.settings = { ...values, reminderMinutes: Number(values.reminderMinutes) }; }, 'Configuración guardada.');
    }
  } catch (error) { if (errorBox) { errorBox.textContent = error.message; errorBox.hidden = false; } else toast(error.message); }
  finally { if (submit.isConnected) submit.disabled = false; }
});
document.addEventListener('input', event => {
  if (event.target.id === 'patient-search') {
    const pos = event.target.selectionStart; query = event.target.value; render();
    $('#patient-search').focus(); $('#patient-search').setSelectionRange(pos, pos);
  }
});
document.addEventListener('change', async event => {
  const el = event.target;
  if (el.id === 'agenda-date' && el.value) { selectedDate = el.value; render(); }
  if (el.id === 'agenda-status') { statusFilter = el.value; render(); }
  if (el.id === 'archived-filter') { showArchived = el.checked; render(); }
  if (el.id === 'import-backup' && el.files[0]) {
    try {
      if (el.files[0].size > 5 * 1024 * 1024) throw new Error('El respaldo supera 5 MB.');
      const file = JSON.parse(await el.files[0].text());
      if (file.format !== 'ronda-backup') throw new Error('Este archivo no es un respaldo de Ronda.');
      validateData(file.data);
      if (confirm('¿Restaurar ' + file.data.patients.length + ' pacientes y ' + file.data.appointments.length + ' citas? Se reemplazará la información actual y se conservará una copia de recuperación.')) await restore(file.data);
    } catch (error) { toast(error.message); }
    finally { if (el.isConnected) el.value = ''; }
  }
});
$('#sync-button').addEventListener('click', () => { if (conflict) navigate('ajustes'); else void sync(); });
window.addEventListener('hashchange', () => navigate(location.hash.slice(1)));
window.addEventListener('online', () => void sync());
window.addEventListener('offline', syncStatus);
window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); installPrompt = event; $('#install-button').hidden = false; });
$('#install-button').addEventListener('click', async () => { if (installPrompt) { await installPrompt.prompt(); installPrompt = null; $('#install-button').hidden = true; } });
document.addEventListener('keydown', event => { if (!editor.open && !['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement?.tagName) && event.key.toLowerCase() === 'n') appointmentDialog(); });
channel?.addEventListener('message', async () => { const latest = await readWorkspace(); if (latest && (latest.generation !== state?.generation || latest.revision !== state?.revision)) { const changed = latest.generation !== state?.generation; state = latest; if (changed && !editor.open) { render(); toast('Vista actualizada con los cambios de otra pestaña.'); } syncStatus(); } });
const reminded = new Set();
async function checkReminders() {
  if (!state || !('Notification' in window) || Notification.permission !== 'granted') return;
  for (const a of data().appointments.filter(a => a.status === 'scheduled')) {
    const diff = new Date(a.date + 'T' + a.time).getTime() - Date.now();
    const key = a.id + a.date + a.time;
    if (diff < 0 || diff > data().settings.reminderMinutes * 60000 || reminded.has(key)) continue;
    try {
      const registration = await navigator.serviceWorker?.getRegistration();
      if (registration) { await registration.showNotification('Tu próxima consulta', { body: 'Tienes una consulta a las ' + a.time + '. Abre Ronda para ver los detalles.', icon: './icons/icon-192.png', tag: key }); reminded.add(key); }
    } catch { /* Notification capability varies by browser. Keep the agenda functional. */ }
  }
}
async function boot() {
  await withWorkspaceLock(async () => {
  state = await readWorkspace();
  if (!state) {
    const initial = migratePrototype();
    state = { data: initial, revision: 0, dirty: initial.appointments.length > 0, generation: uid(), syncedAt: null };
    await saveWorkspace(state);
  }
  });
  validateData(state.data);
  navigate(location.hash.slice(1) || 'hoy');
  if ('serviceWorker' in navigator) {
    try { await navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' }); } catch { toast('La app funciona, pero el modo sin conexión no pudo activarse.'); }
    navigator.serviceWorker.addEventListener('message', e => { if (e.data?.type === 'open-agenda') navigate('agenda'); });
  }
  await sync();
  if (new URLSearchParams(location.search).get('action') === 'new') appointmentDialog();
  setInterval(() => void sync(), 30000);
  setInterval(() => void checkReminders(), 30000);
  void checkReminders();
}
boot().catch(error => {
  main.innerHTML = '<div class="page">' + empty('No pudimos abrir tus datos', esc(error.message) + '<br>Revisa que el navegador permita almacenar información en este sitio y vuelve a cargar.') + '</div>';
});

