# Ronda

Wireframe inicial de baja fidelidad para una PWA de citas, expedientes y cobros. Está hecho con HTML, CSS y JavaScript sin dependencias.

## Abrir en local

Desde esta carpeta:

```powershell
python -m http.server 4173 --bind 127.0.0.1
```

Después abre `http://localhost:4173`.

## Alcance de este boceto

- Panel de hoy con agenda, cobros pendientes y espacios libres.
- Alta rápida de citas guardadas en `localStorage`.
- Vista de expediente de ejemplo.
- Estado en línea/sin conexión, manifiesto instalable y caché mediante Service Worker.
- Wireframe mobile-first con agenda temporal, contexto clínico y controles adaptados a uso táctil.
- Estado visible de conectividad, sincronización e instalación.

No incluye autenticación, base de datos remota, pagos reales ni expedientes clínicos persistentes.
