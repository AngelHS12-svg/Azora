const DEFAULT_APPOINTMENTS = [
  { id: 'a1', time: '09:00', client: 'Nicolás Ruiz', service: 'Sesión de descarga', price: 550, status: 'Pagado', completed: true },
  { id: 'a2', time: '10:30', client: 'Laura Mendoza', service: 'Seguimiento · rodilla', price: 650, status: 'Pendiente', completed: false },
  { id: 'a3', time: '12:00', client: 'Abril Soto', service: 'Valoración inicial', price: 800, status: 'Anticipo', completed: false },
  { id: 'a4', time: '16:00', client: 'Mateo Torres', service: 'Movilidad de hombro', price: 400, status: 'Pendiente', completed: false }
];

const storageKey = 'ronda-appointments-v1';
const schedule = document.querySelector('#schedule-list');
const toast = document.querySelector('#toast');
const appointmentDialog = document.querySelector('#appointment-dialog');
const recordDialog = document.querySelector('#record-dialog');
const form = document.querySelector('#appointment-form');
let installPrompt = null;
let toastTimer;

function loadAppointments() {
  try {
    const stored = JSON.parse(localStorage.getItem(storageKey));
    return Array.isArray(stored) && stored.length ? stored : DEFAULT_APPOINTMENTS;
  } catch {
    return DEFAULT_APPOINTMENTS;
  }
}

let appointments = loadAppointments();

function money(value) {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    maximumFractionDigits: 0
  }).format(value);
}

function escapeHtml(value) {
  const node = document.createElement('span');
  node.textContent = value;
  return node.innerHTML;
}

function renderSchedule() {
  appointments.sort((a, b) => a.time.localeCompare(b.time));
  schedule.innerHTML = appointments.map((item, index) => {
    const isNext = item.id === 'a2' || (!appointments.some(entry => entry.id === 'a2') && index === 0);
    const rowState = item.completed ? 'is-complete' : isNext ? 'is-next' : '';
    const paymentClass = item.status === 'Pagado' ? 'paid' : 'pending';
    return `
      <article class="visit-row ${rowState}" data-id="${item.id}">
        <time class="visit-time">${item.time}</time>
        <span class="visit-track" aria-hidden="true"><i></i></span>
        <button class="visit-main" type="button" data-open-record="${item.id}">
          <strong>${escapeHtml(item.client)}</strong>
          <small>${escapeHtml(item.service)}</small>
        </button>
        <div class="visit-meta">
          <strong>${money(item.price)}</strong>
          <small class="${paymentClass}">${escapeHtml(item.status)}</small>
        </div>
      </article>
    `;
  }).join('');

  document.querySelector('#appointments-count').textContent = String(appointments.length).padStart(2, '0');
  const pending = appointments
    .filter(item => item.status === 'Pendiente')
    .reduce((total, item) => total + Number(item.price), 0);
  document.querySelector('#pending-total').textContent = money(pending);
}

function showToast(message) {
  clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.add('show');
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2500);
}

function openAppointmentDialog(time = '13:30') {
  form.elements.time.value = time;
  appointmentDialog.showModal();
  setTimeout(() => form.elements.client.focus(), 40);
}

document.querySelector('#open-appointment').addEventListener('click', () => openAppointmentDialog());
document.querySelector('#mobile-add').addEventListener('click', () => openAppointmentDialog());
document.querySelector('#open-slot').addEventListener('click', () => openAppointmentDialog('13:30'));
document.querySelector('#close-appointment').addEventListener('click', () => appointmentDialog.close());
document.querySelector('#cancel-appointment').addEventListener('click', () => appointmentDialog.close());

form.addEventListener('submit', event => {
  event.preventDefault();
  if (!form.reportValidity()) return;

  const data = new FormData(form);
  appointments.push({
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    time: data.get('time'),
    client: data.get('client').trim(),
    service: data.get('service').trim(),
    price: Number(data.get('price')),
    status: 'Pendiente',
    completed: false
  });

  localStorage.setItem(storageKey, JSON.stringify(appointments));
  renderSchedule();
  appointmentDialog.close();
  form.reset();
  form.elements.time.value = '13:30';
  showToast(navigator.onLine ? 'Cita guardada y lista para sincronizar' : 'Cita guardada en este dispositivo');
});

schedule.addEventListener('click', event => {
  const trigger = event.target.closest('[data-open-record]');
  if (!trigger) return;
  if (trigger.dataset.openRecord === 'a2') {
    recordDialog.showModal();
  } else {
    showToast('El expediente se abrirá aquí en la siguiente iteración');
  }
});

document.querySelector('#open-record').addEventListener('click', () => recordDialog.showModal());
document.querySelector('#close-record').addEventListener('click', () => recordDialog.close());
document.querySelectorAll('.record-action').forEach(button => {
  button.addEventListener('click', () => showToast('Flujo de nota clínica preparado para la siguiente iteración'));
});

document.querySelector('#mark-arrived').addEventListener('click', event => {
  event.currentTarget.textContent = 'Llegada registrada ✓';
  event.currentTarget.disabled = true;
  showToast('Laura está en sala');
});

const checklist = [...document.querySelectorAll('.session-checklist input')];
checklist.forEach(input => {
  input.addEventListener('change', () => {
    const total = checklist.filter(item => item.checked).length;
    document.querySelector('.session-checklist .panel-heading > small').textContent = `${total}/3`;
  });
});

document.querySelectorAll('[data-section]').forEach(button => {
  button.addEventListener('click', () => {
    const section = button.dataset.section;
    if (section !== 'hoy') {
      showToast(`${button.textContent.trim()}: módulo fuera del alcance de este wireframe`);
      return;
    }
    document.querySelectorAll('[data-section]').forEach(item => {
      item.classList.toggle('is-active', item.dataset.section === 'hoy');
    });
  });
});

function updateNetworkStatus() {
  const status = document.querySelector('#network-status');
  const copy = document.querySelector('#sync-copy');
  status.classList.toggle('offline', !navigator.onLine);
  copy.textContent = navigator.onLine ? 'Todo sincronizado' : 'Guardando en el dispositivo';
  if (!navigator.onLine) showToast('Modo sin conexión activo · puedes seguir trabajando');
}

window.addEventListener('online', updateNetworkStatus);
window.addEventListener('offline', updateNetworkStatus);

window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  installPrompt = event;
  document.querySelector('#install-button').hidden = false;
});

document.querySelector('#install-button').addEventListener('click', async () => {
  if (!installPrompt) return;
  await installPrompt.prompt();
  installPrompt = null;
  document.querySelector('#install-button').hidden = true;
});

document.addEventListener('keydown', event => {
  const editing = ['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement?.tagName);
  if (!editing && event.key.toLowerCase() === 'n') openAppointmentDialog();
});

function setToday() {
  const formatter = new Intl.DateTimeFormat('es-MX', {
    weekday: 'long',
    day: '2-digit',
    month: 'short'
  });
  const date = formatter.format(new Date()).replace('.', '').toUpperCase();
  document.querySelector('#today-label').textContent = `${date} · JORNADA 08:30—18:00`;
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(error => console.warn('Service worker no disponible:', error));
  });
}

setToday();
updateNetworkStatus();
renderSchedule();

if (new URLSearchParams(location.search).get('action') === 'new') {
  window.addEventListener('load', () => openAppointmentDialog());
}
